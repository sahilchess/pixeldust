#This is a simplified version, it is not possible to implement the proper code in Wokwi

import time
from neopixel import Neopixel
from machine import Pin
from rotary_irq_rp2 import RotaryIRQ

pixels = Neopixel(16, 0, 6, "GRB")
p0 = Pin(9, Pin.IN)
p1 = Pin(10, Pin.IN)
rot = RotaryIRQ(pin_num_clk = 0, pin_num_dt = 1, min_val = 0, max_val = 255)

r = 255
g = 255
b = 255
state = "r"
while True:
  r = rot.value()
  print(rot.value())
  pixels.fill([r, g, b])
  if p1.value() == 0:
    b = 0
    g = 0
  else:
    b = 255
    g = 255
  pixels.show()
  time.sleep(0.1)