from neopixel import NeoPixel
from machine import Pin
from time import sleep, sleep_us

class HCSR04:
    def __init__(self, trigger_pin, echo_pin):
        self.echo_timeout_us = 500 * 2 * 30
        self.trigger = Pin(trigger_pin, mode=Pin.OUT)
        self.trigger.value(0)
        self.echo = Pin(echo_pin, mode=Pin.IN)

    def _send_pulse_and_wait(self):
        self.trigger.value(0)
        sleep_us(5)
        self.trigger.value(1)
        sleep_us(10)
        self.trigger.value(0)
        try:
            pulse_time = machine.time_pulse_us(self.echo, 1, self.echo_timeout_us)
            return pulse_time
        except OSError as ex:
            if ex.args[0] == 110:
                raise OSError("Out of range")
            raise ex

    def get_distance_cm(self):
        pulse_time = self._send_pulse_and_wait()
        return (pulse_time * 100 // 582) / 10

WIDTH = 7
HEIGHT = 7
NUM_PIXELS = WIDTH * HEIGHT
CENTER = (WIDTH // 2, HEIGHT // 2)
np = NeoPixel(Pin(26), NUM_PIXELS)

def get_color(distance, max_distance):
    ratio = max(0, min(1, 1 - distance / max_distance))
    r = int(255 * ratio)
    g = int(255 * (1 - ratio))
    return (r, g, 0)

def draw_circle(distance):
    max_distance = 300
    max_radius = 6
    radius = int(max_radius * (1 - min(distance / max_distance, 1)))
    for i in range(NUM_PIXELS):
        np[i] = (0, 0, 0)
    cx, cy = CENTER
    color = get_color(distance, max_distance)
    for y in range(HEIGHT):
        for x in range(WIDTH):
            if (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2:
                index = y * WIDTH + x
                np[index] = color
    np.write()

sensor = HCSR04(3, 4)

def main():
    while True:
        draw_circle(sensor.get_distance_cm())
        sleep(0.05)

if __name__ == "__main__":
    main()
